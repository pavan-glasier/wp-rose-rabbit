<?php
/*
Plugin Name: Push Notifications for WordPress
Plugin URI: https://example.com/push-notifications
Description: Sends push notifications to users.
Version: 1.0.0
Author: GlasierInc
Author URI: https://example.com
License: GPL2
*/

if( ! defined('ABSPATH') ){
    die('-1');
 }

//  echo plugin_dir_url(__FILE__);
function push_notifications_enqueue_scripts() {
    // Enqueue service worker script
    wp_enqueue_script('firebase-app', 'https://www.gstatic.com/firebasejs/8.1.1/firebase-app.js', array(), '8.1.1', true);
    wp_enqueue_script('firebase-messaging', 'https://www.gstatic.com/firebasejs/8.1.1/firebase-messaging.js', array(), '8.1.1', true);

    wp_enqueue_script('push-notifications-service-worker', plugin_dir_url(__FILE__) . 'firebase-messaging-sw.js', array(), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'push_notifications_enqueue_scripts');


function push_notifications_settings_page() {
    // Add plugin settings page under the "Settings" menu
    add_options_page('Push Notifications Settings', 'Push Notifications', 'manage_options', 'push-notifications-settings', 'push_notifications_render_settings');
}
add_action('admin_menu', 'push_notifications_settings_page');

function push_notifications_render_settings() {
    // Render the settings page content
    ?>
    <div class="wrap">
        <h1>Push Notifications Settings</h1>
        <form method="post" action="options.php">
            <?php
            // Output the settings fields
            settings_fields('push-notifications-settings-group');
            do_settings_sections('push-notifications-settings-group');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}
