// importScripts('https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js');
// importScripts('https://www.gstatic.com/firebasejs/9.22.2/firebase-messaging.js');
if( 'undefined' === typeof window){
    importScripts('https://www.gstatic.com/firebasejs/8.1.1/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/8.1.1/firebase-messaging.js');

}
let firebaseConfig = {
    apiKey: "AIzaSyAd472CShCMonQPhYd-jVJo_WzOL9Q4yxM",
    authDomain: "push-notification-wordpress.firebaseapp.com",
    projectId: "push-notification-wordpress",
    storageBucket: "push-notification-wordpress.appspot.com",
    messagingSenderId: "164377572488",
    appId: "1:164377572488:web:024c5721eaf6ade0c91b3d",
    measurementId: "G-JEFNW1FP0Y"
};// Initialize Firebase
firebase.initializeApp(firebaseConfig);
// console.log('firebase :>> ', firebase);
// console.log('firebase.m :>> ', firebase.messaging());
// const messaging = firebase.messaging();
// // messaging.onBackgroundMessage((payload) => {
// //     console.log('[firebase-messaging-sw.js] Received background message ', payload);
// //     const notificationTitle = payload.notification.title;
// //     const notificationOptions = {
// //         body: payload.notification.body,
// //     };
// //     return self.registration.showNotification(notificationTitle, notificationOptions);
// // });
// self.addEventListener('notificationclick', event => {
//    console.log(event)
// });

self.addEventListener("install", (event) => {
    console.log(event)
})

if('serviceWorker' in navigator){
    const messaging = firebase.messaging()
    navigator.serviceWorker.register('http://192.168.0.128/rose_and_rabbit/wp-content/plugins/push-notifications-for-wordpress/firebase-messaging-sw.js')
    .then((register) => {
        console.log('register :>> ', register);
        messaging.requestPermission().then(() => {
        messaging.getToken()
            .then((fcmToken) => {
                console.log(fcmToken)
                messaging.onMessage((payload) => {
                    console.log("onMessage event fired",payload)
                })
            });
        });
    })
} else {
    console.log('Service Worker not supported')
}